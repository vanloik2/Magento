var config = {
    "map": {
        "*": {
            'Magento_Checkout/js/model/shipping-save-processor/default': 'Checkout_Donate/js/action/shipping-save-custom-donate'
        }
    },
};

