define(['jquery', 'ko', 'domReady!'], function ($, ko) {

    return function (config, element) {
        this.testMukesh = function () {
            alert('test ok..');
        }
    }
})
